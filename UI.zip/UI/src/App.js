import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './Components/Home'; // Import your Home component
import Create from './Components/Create'; // Import your Home component



function App() {
  
  return (

    <Router>
    <Routes>
      <Route path="/" element={<Home />} /> {/* Home route */}
      <Route
        path="/createCourse"
        element={
          <Create />
        }
      />
    </Routes>
  </Router>
    
  );
}

export default App;
